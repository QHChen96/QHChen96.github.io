Claude Code 2.1.314 图解与完整案例包
作者：小陈
版本核验日期：2026-10-31（北京时间）
博客文章：https://qhchen96.github.io/posts/2026/10/31/p18-claude-code-harness-architecture/

打开 claude-code-architecture.html：四张动态图、12 节中文讲义和官方来源。
页面与动态图可离线阅读；点击外部来源或博客链接时需要网络。
图可切换、暂停和恢复；手机可选“原尺寸”查看细节。
动画日志是机制示意，不是真实 Agent 运行记录、固定执行顺序或性能测量。

文件说明：
diagrams/：独立 HTML 与可编辑 spec.json，由 @rokoai/arch-diagram@1.2.3 生成。
lab/：订单运费折扣错误的基线、四个验收测试与项目约定。
reference/：完整修复实现与真实测试输出，全部答案直接提供。
verify_case.py：在临时目录中分别复现基线与修复结果，不改写案例源文件。

复现案例（仅需 Python 3.10+ 标准库）：
  python verify_case.py
预期：基线 4 个测试中 3 个失败、1 个通过；修复实现 4 个测试全部通过。
未启动 Claude Code，未调用模型 API。模型工具轨迹不能由这些测试结果推断。

重新生成单张图（需要 Node.js；从本包根目录运行）：
  npx @rokoai/arch-diagram@1.2.3 build diagrams/core.spec.json diagrams/core.html
  npx @rokoai/arch-diagram@1.2.3 check diagrams/core.html
其余图将 core 换为 context、extensions、collaboration。
修改单图后，综合阅读器内的嵌入图不会自动更新，可直接打开重新生成的单图。

版本与边界：
2.1.314 是核验时的 CLI latest 正式版，不等于 stable、模型或 SDK 的版本。
GitHub 发布时刻：2026-10-30T01:06:26Z。
Agent Teams 在该快照中为实验功能、默认关闭，仅交互入口可启动 teammates。
公开行为以运行器、账号、模型、提供商、宿主和配置条件为准，讲义逐节注明。
provenance.json 保留核验日期、官方来源和验证范围。
THIRD_PARTY_NOTICES.txt 保留原绘图引擎的 MIT 许可证。
