"""Reproduce the buggy baseline and fixed implementation in temporary directories."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
report = {"case": "discount_goods_before_adding_shipping", "claude_code_executed": False, "model_api_called": False}
for label, source, expected_code in (
    ("baseline", root / "lab/pricing.py", 1),
    ("reference_solution", root / "reference/pricing_solution.py", 0),
):
    with tempfile.TemporaryDirectory(prefix="pricing-case-") as directory:
        target = Path(directory)
        shutil.copy2(source, target / "pricing.py")
        shutil.copy2(root / "lab/test_pricing.py", target / "test_pricing.py")
        result = subprocess.run([sys.executable, "-B", "-m", "unittest", "-v"], cwd=target, text=True, capture_output=True)
        output = (result.stdout + result.stderr).replace(str(target / "test_pricing.py"), "lab/test_pricing.py")
        if result.returncode != expected_code or "Ran 4 tests" not in output:
            raise SystemExit(f"Unexpected result for {label}: {output}")
        if label == "baseline" and "FAILED (failures=3)" not in output:
            raise SystemExit(f"Unexpected baseline failures: {output}")
        report[label] = {"tests": 4, "passed": 1 if label == "baseline" else 4, "exit_code": result.returncode, "output": output}
        if label == "baseline":
            report[label]["expected_failures"] = 3
print(json.dumps(report, ensure_ascii=False, indent=2))
