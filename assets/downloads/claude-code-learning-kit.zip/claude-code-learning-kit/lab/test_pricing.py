import unittest

from pricing import payable_cents


class PricingContractTests(unittest.TestCase):
    def test_no_discount(self) -> None:
        self.assertEqual(payable_cents(10000, 2, 0, 500), 20500)

    def test_shipping_is_not_discounted(self) -> None:
        self.assertEqual(payable_cents(10000, 2, 10, 500), 18500)

    def test_full_goods_discount_keeps_shipping(self) -> None:
        self.assertEqual(payable_cents(10000, 2, 100, 500), 500)

    def test_round_goods_down_before_adding_shipping(self) -> None:
        self.assertEqual(payable_cents(999, 1, 10, 100), 999)


if __name__ == "__main__":
    unittest.main()
