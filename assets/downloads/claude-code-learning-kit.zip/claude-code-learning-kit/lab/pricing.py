"""订单金额案例的错误基线：用于复现运费也被打折的问题。"""


def payable_cents(
    unit_price_cents: int,
    quantity: int,
    discount_percent: int = 0,
    shipping_cents: int = 0,
) -> int:
    """返回应付金额，单位为分。输入均满足 README 中的有效范围。"""
    subtotal = unit_price_cents * quantity
    return (subtotal + shipping_cents) * (100 - discount_percent) // 100
