"""订单金额案例的完整修复实现。"""


def payable_cents(
    unit_price_cents: int,
    quantity: int,
    discount_percent: int = 0,
    shipping_cents: int = 0,
) -> int:
    """先计算商品折后金额，再原额加入运费。"""
    subtotal = unit_price_cents * quantity
    discounted_goods = subtotal * (100 - discount_percent) // 100
    return discounted_goods + shipping_cents
